<footer class="page-footer grey darken-1">
  <div class="container">
    <div class="row">
      <div class="col l6 s12">
        <h5 class="white-text">Truewalls</h5>
        <p class="grey-text text-lighten-4">A HQ Wallpapers For Your Mobile & Desktop Devices</p>
      </div>
      <div class="col l4 offset-l2 s12">
        <h5 class="white-text">Social Links</h5>
        <ul>
          <li><a class="grey-text text-lighten-3" href="#!"><i class="fab fa-facebook medium"></i></a></li>
          <li><a class="grey-text text-lighten-3" href="#!"><i class="fab fa-youtube medium"></i></a></li>
          <li><a class="grey-text text-lighten-3" href="#!"> <i class="fab fa-behance-square medium"></i></a></li>
          <li><a class="grey-text text-lighten-3" href="#!"><i class="fab fa-instagram medium"></i></a></li>
        </ul>
      </div>
    </div>
  </div>
  <div class="footer-copyright">
    <div class="container">
      © 2019 Copyright TrueWalls
      
    </div>
  </div>
</footer>
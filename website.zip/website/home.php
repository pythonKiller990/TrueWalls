<!--all necessary php scripts comes here-->
<?php include 'require.php'; ?>
<!--End here-->
<!DOCTYPE html>
<html>
  <head>
    <meta name="description" content="Premier East Valley Realty
    specializing in luxury real estate. We are your location
    specialists.">
    <title>TrueWalls</title>
    <link rel="shortcut icon" type="image/png" href="img/playstore-icon.png">
    <!-- Compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script>
    $( function() {
    $( ".draggable" ).draggable();
    } );
    </script>
    <link rel="stylesheet" type="text/css" href="css/custom.css">
    <!--Import Google Icon Font-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Abril+Fatface&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Dancing+Script&display=swap" rel="stylesheet">
    <!-- Main -->
    <link href="https://fonts.googleapis.com/css?family=Lobster&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/progressively/dist/progressively.min.css">
    
    <!--Let browser know website is optimized for mobile-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    
    
  </head>
  <?php if (theme()=='checked') {
  echo '<body style="background-color:#000000;">';
    }
    else{
    echo '<body style="background-color:#ffffff;">';
      } ?>
      
      
      <!--Navbar start from here-->
      <?php include 'navbar.php'; ?>
      <!--Navbar Ends Here-->
      <!--Category Dropdown starts from here-->
      <?php include 'dropdown.php'; ?>
      <!--dropdown ends here-->
      
      <!--sidenav start from here-->
      <?php include 'sidenav.php'; ?>
      <!--sidenav ends here-->
      <!--gotoup button-->
      <a class="btn btn-floating grey" id="button"><i class="material-icons">arrow_upward</i></a>
      <!--goto up button end here-->
      <!--account info start from here-->
      <?php include 'user.php'; ?>
      <!-- account info ends here -->
      
      <!--upload modal Start from here-->
      <?php include 'uploadmodal.php'; ?>
      <!--upload modal ends here-->
      <!--main content-->
      
      <br><br><br><br>
      
      <br><br><br><br>

      <!--getting theme of the user and implement the logic-->
      <input type="hidden" id="theme" value="<?php echo $theme ?>">
      <!--Main Content Goes Here-->
      <?php include 'content.php'; ?>
      <!--Main Content End Here-->
      <?php include 'footer.php'; ?>
      
      <!--ALL Required javascript comes here-->
      <?php include 'javascript.php'; ?>
      <!--js ends here-->
      
      
      
      
      
    </body>
  </html>
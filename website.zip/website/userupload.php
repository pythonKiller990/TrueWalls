<?php session_start(); ?>
<?php
include_once 'includes/dbh.php';
$fullname = "";
$img = "";
$user = "";
if (isset($_SESSION['username'])) {
$user = $_SESSION['username'];
}
else
{
$user = "Admin";
$theme ='unchecked';
}
$sql = "SELECT * FROM users WHERE userid = ?";
$stmt = mysqli_stmt_init($conn);
if (!mysqli_stmt_prepare($stmt,$sql)) {
echo "Statement Error!";
}
else
{
mysqli_stmt_bind_param($stmt,"s",$user);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
if ($row = mysqli_fetch_assoc($result)) {
$fullname = $row['fname'];
$img = $row['avatar'];
$userid = $row['userid'];
$theme = $row['theme'];
}
}

function theme()
{
$userTheme = $GLOBALS['theme'];
return $userTheme;
}
function userImage()
{
$image = $GLOBALS['img'];
return $image;
}
function userName()
{
$name = $GLOBALS['fullname'];
return $name;
}
function userid()
{
$uid = $GLOBALS['userid'];
return $uid;
}
?>
<?php
function Instacount()
{
$raw = file_get_contents('https://www.instagram.com/inder_jeet786'); //replace with user
preg_match('/\"edge_followed_by\"\:\s?\{\"count\"\:\s?([0-9]+)/',$raw,$m);
$count = intval($m[1]);
return $count;
}
?>
<?php function youtube()
{
// Change channelid value to match your YouTube channel ID
$url = 'https://www.youtube.com/subscribe_embed?channelid=UCTdCbTPOkekdtoOUN_Mj-AQ';
// Fetch the Subscribe button HTML
$button_html = file_get_contents( $url );
// Extract the subscriber count
$found_subscribers = preg_match( '/="0">(\d+)</i', $button_html, $matches );
if ( $found_subscribers && isset( $matches[1] ) ) {
return intval($matches[1]);
}
}?>
<!DOCTYPE html>
<html>
  <head>
    <title>TrueWalls-UserUpload</title>
    <link rel="shortcut icon" type="image/png" href="img/playstore-icon.png">
    <!-- Compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script>
    $( function() {
    $( ".draggable" ).draggable();
    } );
    </script>
    <!--Import Google Icon Font-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <!-- Main -->
    <!-- custom scrollbar stylesheet -->
    <link rel="stylesheet" href="css/jquery.mCustomScrollbar.css">
    
    <!--Let browser know website is optimized for mobile-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  </head>
  <style type="text/css">

    .edit
    {
      transition: all .5s ease-in-out;
    }

    .edit:hover
    {
      transition: all .5s ease-in-out;
      transform: rotate(-55deg);
      background-color: indigo;
    }
  body
  {
  margin: 0;
  padding: 0;

  }
  
  /* Let's get this party started */
  ::-webkit-scrollbar {
  width: 10px;
  height: 10px;
  }
  
  /* Track */
  ::-webkit-scrollbar-track {
  -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
  -webkit-border-radius: 10px;
  border-radius: 10px;
  }
  
  /* Handle */
  ::-webkit-scrollbar-thumb {
  -webkit-border-radius: 10px;
  border-radius: 10px;
  background: #ffffff;
  -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.5);
  }
  ::-webkit-scrollbar-thumb:window-inactive {
  background: rgba(255,0,0,0.4);
  }
  img
  {
  border-radius: 10px;
  transform-style: preserve-3d;
  transform: translateZ(20px);
  }
  #button {
  display: inline-block;
  
  text-align: center;
  position: fixed;
  bottom: 30px;
  right: 30px;
  transition: background-color .3s,
  opacity .5s, visibility .5s;
  opacity: 0;
  visibility: hidden;
  z-index: 1000;
  }
  #button::after {
  content: "\f077";
  font-family: FontAwesome;
  font-weight: normal;
  font-style: normal;
  font-size: 2em;
  line-height: 50px;
  color: #fff;
  }
  #button:hover {
  cursor: pointer;
  background-color: #333;
  }
  #button:active {
  background-color: #555;
  }
  #button.show {s
  opacity: 1;
  visibility: visible;
  }
  .btn1 {
  border: 2px solid gray;
  color: gray;
  background-color: white;
  padding: 8px 20px;
  border-radius: 8px;
  font-size: 20px;
  font-weight: bold;
  }
  .upload input[type=file] {
  font-size: 100px;
  position: absolute;
  left: 0;
  top: 0;
  opacity: 0;
  }
  .upload {
  position: relative;
  overflow: hidden;
  display: inline-block;
  }
  
  
  </style>
</head>
 <?php if (theme()=='checked') {
  echo '<body style="background-color:#000000;">';
    }
    else{
    echo '<body style="background-color:#ffffff;">';
      } ?>
    
    
      <div class="navbar-fixed">
        <nav class="white" id="nav">
          <div class="nav-wrapper container">
           
            <a href="#" data-target="mobile-demo" class="sidenav-trigger" style="color: #000;"><i class="material-icons" id="hamburger">menu</i></a>
            <ul class="left hide-on-med-and-down">
              <li><a href="home.php" class="tooltipped" data-position="center" data-tooltip="Go to Home" style="color: #000000" id="brand"><i class="material-icons">home</i></a></li>
            </ul>
            
          </div>
        </nav>
      </div>
   
    <ul class="sidenav" id="mobile-demo">
      
      <li><a href="home.php" class="tooltipped" data-position="center" data-tooltip="cancel" style="color: #000000"><i class="material-icons">arrow_back</i>Go Back</a></li>
    </ul>
    <a class="btn btn-floating grey" id="button"><i class="material-icons">arrow_upward</i></a>
    <!--about dev ends here-->
    <!--main content-->
    
    <br><br><br><br>
    <div class="container">
      
      <br><br><br>
      <div class="row">
        <div class="col s12 l12 center xl12 m12">
          <center><img src="includes/avatar/<?php echo userImage(); ?>" alt="Contact Person" class="responsive-img" width="150" height="150" style="border-radius: 50%;"><br>
          <p style="font-size: 25px;font-style: bold;" id="heading"><?php echo userName(); ?></p><br>
          <a href="profile_edit.php" class="btn btn-floating btn-large red accent-3 edit pulse" style="color: #000;text-align: center;"><i class="fas fa-cog white-text"></i></a></center>
        </div>
      </div>
      
      <div class="row" id="gallery">
        <?php
        include_once 'includes/dbh.php';
        $id = userid();
        $sql = "SELECT * FROM galleryExamp WHERE userid = ?";
        $stmt = mysqli_stmt_init($conn);
        if (!mysqli_stmt_prepare($stmt,$sql)) {
        echo "Statement Error!";
        }
        else
        {
        mysqli_stmt_bind_param($stmt,"s",$id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        while($row = mysqli_fetch_assoc($result))
        {
        echo '
        
        <div class="col s12 l4 m12">
          <a href="#modal'.$row['orderGallery'].'" class="modal-trigger">
          <img src="includes/walls/'. $row['imgFullName'].'" class="responsive-img gallery tooltipped ui-widget-content draggable" data-tilt data-position="right" data-tooltip="'.$row['Category'].'"></a>
          
          
        </div>
        
        ';
        }
        }
        
        ?>
      </div>
      <?php
      include_once 'includes/dbh.php';
      $sql = "SELECT * FROM galleryExamp WHERE userid = ?";
      $stmt = mysqli_stmt_init($conn);
      if (!mysqli_stmt_prepare($stmt,$sql)) {
      echo "Statement Error!";
      }
      else
      {
      mysqli_stmt_bind_param($stmt,"s",$id);
      mysqli_stmt_execute($stmt);
      $result = mysqli_stmt_get_result($stmt);
      while($row = mysqli_fetch_assoc($result))
      {
      echo '
      <div id="modal'.$row['orderGallery'].'" class="modal">
        <div class="modal-content">
          <div class="row">
            <div class="col s12 l6 m6 xl6">
              <img src="includes/walls/'.$row['imgFullName'].'" class="responsive-img">
              
            </div>
            <div class="col s12 l6 xl6 m6">
              
              
              <form action="del.php" method="POST">
                <input type="hidden" value="'.$row['idGallery'].'" name="uid">
              <button  class="btn btn-large btn-floating del red" name="del"><i class="material-icons">delete</i></button></form></div>
            </div>
          </div>
          
        </div>';
        }
        }
        ?>
      </div>

      <!--getting theme of the user and implement the logic-->
      <input type="hidden" id="theme" value="<?php echo $theme ?>">
      
      
      <!-- Compiled and minified JavaScript -->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
      <script src="https://kit.fontawesome.com/f3226cd6c1.js"></script>
      <script type="text/javascript" src="js/tilt.jquery.js"></script>
      <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
      <script type="text/javascript">
      $(document).ready(function(){
      $('.sidenav').sidenav();
      $('.modal').modal();
      $('.tooltipped').tooltip();
      $( "#draggable" ).draggable();
      $('.fixed-action-btn').floatingActionButton({
      toolbarEnabled: true
      });
      $('.gallery').tilt({
      opacity:.5,
      
      glare: true,
      maxGlare: .5
      })
      var btn = $('#button');
      $(window).scroll(function() {
      if ($(window).scrollTop() > 300) {
      btn.addClass('show');
      } else {
      btn.removeClass('show');
      }
      });
      btn.on('click', function(e) {
      e.preventDefault();
      $('html, body').animate({scrollTop:0}, '300');
      });
      });
      </script>
      <script src="js/jquery.overlayScrollbars.js"></script>
      <script type="text/javascript">
      $(document).ready(function(){
      
      $(window).scroll(function(){
      
      var scroll = $(window).scrollTop();
      if (scroll > 20) {
      $(".hero").css("background-image" , "url('img/back4.png')");
      $(".hero").css("transition","2s all");
      $("#button").add("grey accent-3");
      
      
      }
      else{
      $(".hero").css("background-image" , "url('img/back3.png')");
      $(".hero").css("transition-duration","2s");
      
      
      
      }
      })
      })
      </script>
      <script type="text/javascript">
      function upload()
      {
      swal("Good job!", "You clicked the button!", "success");
      }
      </script>
      <!-- custom scrollbar plugin -->
      <script src="js/jquery.mCustomScrollbar.js"></script>
      
      <script>
      (function($){
      $(window).on("load",function(){
      
      $("#content-1").mCustomScrollbar({
      autoHideScrollbar:true,
      theme:"rounded"
      });
      
      });
      })(jQuery);
      </script>

      <script type="text/javascript">
      $(document).ready(function()
      {

            var a =$('#theme').val();
            if (a == 'checked') 
            {
                  $('#heading').css('color','#ffffff');
                  $('nav').removeClass('black accent-3');
                  $('nav').addClass('white accent-3');
                  $('#brand').removeClass('brand-logo white-text');
                  $('#brand').addClass('brand-logo black-text');
                  $('#hamburger').removeClass('material-icons');
                  $('#hamburger').addClass('material-icons white-text');
                  $('#hamburger').removeClass('material-icons white-text');
                  $('#hamburger').addClass('material-icons black-text');
                  
            }
            else
            {
                  $('#heading').css('color','#999999');
                  $('nav').removeClass('white accent-3');
                  $('nav').addClass('black accent-3');
                  $('#brand').removeClass('brand-logo black-text');
                  $('#brand').addClass('brand-logo white-text');
                  $('#hamburger').removeClass('material-icons');
                  $('#hamburger').addClass('material-icons white-text');
            }

      });
</script>
    </body>
  </html>
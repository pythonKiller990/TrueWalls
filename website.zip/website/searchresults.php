<?php session_start(); ?>
<?php
include_once 'includes/dbh.php';
$fullname = "";
$img = "";
$user = "";
if (isset($_SESSION['username'])) {
$user = $_SESSION['username'];
}
else
{
$user = "Admin";
$theme ='unchecked';
}
$sql = "SELECT * FROM users WHERE userid = ?";
$stmt = mysqli_stmt_init($conn);
if (!mysqli_stmt_prepare($stmt,$sql)) {
echo "Statement Error!";
}
else
{
mysqli_stmt_bind_param($stmt,"s",$user);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
if ($row = mysqli_fetch_assoc($result)) {
$fullname = $row['fname'];
$img = $row['avatar'];
$userid = $row['userid'];
$theme = $row['theme'];
}
}
function theme()
{
$userTheme = $GLOBALS['theme'];
return $userTheme;
}
function userImage()
{
$image = $GLOBALS['img'];
return $image;
}
function userName()
{
$name = $GLOBALS['fullname'];
return $name;
}
function userid()
{
$uid = $GLOBALS['userid'];
return $uid;
}
?>
<!DOCTYPE html>
<html>
  <head>
    <title><?php echo $_GET['search']; ?></title>
    <link rel="shortcut icon" type="image/png" href="img/playstore-icon.png">
    <!-- Compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    
    <!--Import Google Icon Font-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <!-- Main -->
    <!-- custom scrollbar stylesheet -->
    <link rel="stylesheet" href="css/jquery.mCustomScrollbar.css">
    
    <!--Let browser know website is optimized for mobile-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  </head>
  <style type="text/css">
  body
  {
  margin: 0;
  padding: 0;
  }
  
  /* Let's get this party started */
  ::-webkit-scrollbar {
  width: 2px;
  height: 10px;
  }
  
  /* Track */
  ::-webkit-scrollbar-track {
  -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
  -webkit-border-radius: 10px;
  border-radius: 10px;
  }
  
  /* Handle */
  ::-webkit-scrollbar-thumb {
  -webkit-border-radius: 5px;
  border-radius: 10px;
  background: #000000;
  -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.5);
  }
  ::-webkit-scrollbar-thumb:window-inactive {
  background: rgba(255,0,0,0.4);
  }
  img
  {
  border-radius: 10px;
  transform-style: preserve-3d;
  transform: translateZ(20px);
  }
  #button {
  display: inline-block;
  
  text-align: center;
  position: fixed;
  bottom: 30px;
  right: 30px;
  transition: background-color .3s,
  opacity .5s, visibility .5s;
  opacity: 0;
  visibility: hidden;
  z-index: 1000;
  }
  #button::after {
  content: "\f077";
  font-family: FontAwesome;
  font-weight: normal;
  font-style: normal;
  font-size: 2em;
  line-height: 50px;
  color: #fff;
  }
  #button:hover {
  cursor: pointer;
  background-color: #333;
  }
  #button:active {
  background-color: #555;
  }
  #button.show {s
  opacity: 1;
  visibility: visible;
  }
  .btn1 {
  border: 2px solid gray;
  color: gray;
  background-color: white;
  padding: 8px 20px;
  border-radius: 8px;
  font-size: 20px;
  font-weight: bold;
  }
  .upload input[type=file] {
  font-size: 100px;
  position: absolute;
  left: 0;
  top: 0;
  opacity: 0;
  }
  .upload {
  position: relative;
  overflow: hidden;
  display: inline-block;
  }
  
</style>
</head>
<?php if ($theme=='checked') {
echo '<body style="background-color:#000000;">';
  }
  else{
  echo '<body style="background-color:#ffffff;">';
    } ?>
    
    <div class="navbar-fixed">
          <nav class="black accent-3" id="nav">
            <div class="nav-wrapper container">
              <a href="home.php" class="brand-logo white-text" id="brand"><i class="material-icons">home</i></a>
              <a href="#" data-target="mobile-demo" class="sidenav-trigger black-text"><i class="material-icons" id="hamburger">menu</i></a>
              
              
            </div>
          </nav>
        </div>
    
    <ul class="sidenav" id="mobile-demo">
      
      <li><a href="home.php" class="tooltipped" data-position="center" data-tooltip="Home" style="color: #000000"><i class="material-icons">home</i>Home</a></li>
    </ul>
    
    <!--about dev ends here-->
    <!--main content-->
    
    <br><br><br><br>
    <div class="container">
      
      <br><br><br>
      <center><img src="img/<?php echo $_GET['search'] ?>.png" width="150" height="150" style="border-radius: 50%;"></center>
      <div class="row">
        <div class="col s12 l12 xl12 md12">
          <center><h3 id="heading">
          <?php
          $sk = "";
          
          $skey=$_GET['search'];
          $sk = $skey;
          echo $sk;
          
          
          function getSkey()
          {
          $key = $GLOBALS['sk'];
          return $key;
          }
          ?>
          </h3><p>Total Results Found:
            <?php
            $searchkey = getSkey();
            $sql = "SELECT * FROM galleryExamp WHERE Category LIKE '$searchkey'";
            $res = mysqli_query($conn,$sql);
            $rc = mysqli_num_rows($res);
            echo $rc;
            ?>
          </p>
        </div>
      </div>
      
      <div class="row" id="gallery">
        <?php
        $keyword = getSkey();
        $sql = "SELECT * FROM galleryExamp WHERE Category LIKE ?";
        $stmt = mysqli_stmt_init($conn);
        if (!mysqli_stmt_prepare($stmt,$sql)) {
        echo "Statement Error!";
        }
        else
        {
        mysqli_stmt_bind_param($stmt,"s",$keyword);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $rowcount = mysqli_num_rows($result);
        if ($rowcount > 0) {
        
        while($row = mysqli_fetch_assoc($result))
        {
        echo '
        
        <div class="col s12 l4 m12">
          <a href="#modal'.$row['orderGallery'].'" class="modal-trigger">
          <img src="includes/walls/'. $row['imgFullName'].'" class="responsive-img gallery tooltipped ui-widget-content draggable" data-tilt data-position="right" data-tooltip="'.$row['Category'].'"></a>
          
          
        </div>
        
        ';
        }}
        else
        {
        header('location:searcherror.php?data=notfound');
        exit();
        }
        }
        ?>
      </div>
      <?php function rowCount()
      {
      $rowcount = $GLOBALS['$rowCount'];
      $rc = (string)$rowcount;
      return $rc;
      } ?>
      <?php
      include_once 'includes/dbh.php';
      $keyword = getSkey();
      $sql = "SELECT * FROM galleryExamp WHERE Category LIKE  ?";
      $stmt = mysqli_stmt_init($conn);
      if (!mysqli_stmt_prepare($stmt,$sql)) {
      echo "Statement Error!";
      }
      else
      {
      mysqli_stmt_bind_param($stmt,"s",$keyword);
      mysqli_stmt_execute($stmt);
      $result = mysqli_stmt_get_result($stmt);
      while($row = mysqli_fetch_assoc($result))
      {
      echo '
  <div id="modal'.$row['orderGallery'].'" class="modal">
    <div class="modal-content">
      <div class="row">
        <div class="col s12 l6 m6 xl6">
          <img src="includes/walls/'.$row['imgFullName'].'" class="responsive-img materialboxed">
          
        </div>
        <div class="col s12 l6 xl6 m6">
          
          <br><br><br><br><div class="a2a_kit a2a_kit_size_32 a2a_default_style">
            <a class="a2a_button_twitter"></a>
            <a class="a2a_button_email"></a>
            <a class="a2a_button_whatsapp"></a>
          </div><br>
          
          <a href="includes/walls/'.$row['imgFullName'].'" class="btn btn-large  red" download style="border-radius:50px;">Download</a><p>Resolution: ';
          echo $row['Res'];
        echo '</p><p>Size : ';
        echo $row['size'].'MB';
      echo '</p><p>Category: ';
      echo $row['Category'];
      echo '</p><p>Upload By: ';
   echo $row['personGallery'];
    echo '</p></div>
  </div>
</div>

</div>';
      }
      }
      ?>
    </div>
    <!--getting theme of the user and implement the logic-->
      <input type="hidden" id="theme" value="<?php echo $theme ?>">
    <script async src="https://static.addtoany.com/menu/page.js"></script>
    
    <!-- Compiled and minified JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script type="text/javascript" src="js/tilt.jquery.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script type="text/javascript">
    $(document).ready(function(){
    $('.sidenav').sidenav();
    $('.modal').modal();
    $('.tooltipped').tooltip();
    $('.materialboxed').materialbox();
    $( "#draggable" ).draggable();
    $('.fixed-action-btn').floatingActionButton({
    toolbarEnabled: true
    });
    $('.gallery').tilt({
    opacity:.5,
    
    glare: true,
    maxGlare: .5
    })
    
    });
    </script>

  <script type="text/javascript">
      $(document).ready(function()
      {

            var a = $('#theme').val();
            if (a == 'checked') 
            {
              //console.log(a);
                  $('#heading').css('color','#ffffff');
                  $('nav').removeClass('black accent-3');
                  $('nav').addClass('white accent-3');
                  $('#brand').removeClass('brand-logo white-text');
                  $('#brand').addClass('brand-logo black-text');
                  $('#hamburger').removeClass('material-icons white-text');
                  $('#hamburger').addClass('material-icons black-text');
                  
            }
            else
            {
             // console.log(a);
                  $('#heading').css('color','#999999');
                  $('nav').removeClass('white accent-3');
                  $('nav').addClass('black accent-3');
                  $('#brand').removeClass('brand-logo black-text');
                  $('#brand').addClass('brand-logo white-text');
                  $('#hamburger').removeClass('material-icons');
                  $('#hamburger').addClass('material-icons white-text');
            }

      });
</script>
    
    
    
  </body>
</html>
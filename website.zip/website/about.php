<!--all necessary php scripts comes here-->
<?php include 'require.php'; ?>
<!DOCTYPE html>
<html>
	<head>
		<title>About-Dev</title>
		<link rel="shortcut icon" type="image/png" href="img/playstore-icon.png">
		<!-- Compiled and minified CSS -->
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
		
		<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
		<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
		<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
		
		<!--Import Google Icon Font-->
		<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
		<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
		<!-- Main -->
		<!-- custom scrollbar stylesheet -->
		<link rel="stylesheet" href="css/jquery.mCustomScrollbar.css">
		
		<!--Let browser know website is optimized for mobile-->
		<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
		<style type="text/css">
			body
			{
				margin: 0;
				padding:0;
			}
			@media screen (max-width: 768px)
			{
				body
				{
					background-color:#262626;
				}
			}
		</style>
	</head>
	<?php if (theme()=='checked') {
  echo '<body style="background-color:#000000;">';
    }
    else{
    echo '<body style="background-color:#ffffff;">';
      } ?>
			<br><br><br><br><br>
			<!--getting theme of the user and implement the logic-->
      <input type="hidden" id="theme" value="<?php echo $theme ?>">
			<div class="container">
				<div class="row">
					<div class="col s12 l12 xs12">
						<center><img src="img/dev.png" width="150" height="150"></center>
					</div>
					
				</div>
				<div class="row">
					<div class="col s12 l12 xs12">
						<center><h1 style="color: #999;" id="dev">Sumit Kumar Bighaniya</h1></center>
					</div>
				</div>
				<div class="row">
					<div class="col s12 l12 xs12">
						<center><p id="desc">I am a computer science student & a self Developer,I like Web development very Much.Based on Bangaluru(India).</p></center>
					</div>
				</div>
				<div class="row">
					<div class="col s12 l12 xs12">
						<center><a href="home.php" class="btn btn-floating"><i class="material-icons">home</i></a></center>
					</div>
				</div>
				
				<div class="fixed-action-btn">
					<a class="btn-floating btn-large red">
						<i class="large material-icons">person</i>
					</a>
					<ul>
						<li><a class="btn-floating red"><i class="fa fa-youtube"></i></a></li>
						<li><a class="btn-floating indigo darken-1"><i class="fa fa-facebook"></i></a></li>
						<li><a class="btn-floating purple"><i class="fa fa-instagram"></i></a></li>
						<li><a class="btn-floating blue"><i class="material-icons">mail</i></a></li>
					</ul>
				</div>
			</div>
			<!-- Compiled and minified JavaScript -->
			<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
			<script type="text/javascript" src="js/tilt.jquery.js"></script>
			<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
			<script type="text/javascript">
			$(document).ready(function(){
			$('.sidenav').sidenav();
			$('.modal').modal();
			$('.tooltipped').tooltip();
			$( "#draggable" ).draggable();
			$(document).ready(function(){
			$('.fixed-action-btn').floatingActionButton();
			});
			
			$('.gallery').tilt({
			opacity:.5,
			
			glare: true,
			maxGlare: .5
			})
			});
			
			</script>

			<script type="text/javascript">
      $(document).ready(function()
      {

            var a =$('#theme').val();
            if (a == 'checked') 
            {
                  $('#dev').css('color','#ffffff');
                  $('#desc').css('color','#ffffff');
                  
                  
            }
            else
            {
                  $('#dev').css('color','#999999');
                  $('#desc').css('color','#999999');
            }

      });
</script>
			
		</body>
	</html>
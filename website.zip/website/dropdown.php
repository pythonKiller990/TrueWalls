<ul id='dropdown1' class='dropdown-content teal accent-3' style="width: 600px;overflow: hidden;">
        <li><a href="searchresults.php?search=Animals">Animals</a></li>
        <li><a href="searchresults.php?search=Abstract">Abstract</a></li>
        <li><a href="searchresults.php?search=Architectures">Architectures</a></li>
        <li><a href="searchresults.php?search=Peoples">Peoples</a></li>
        <li><a href="searchresults.php?search=Girls">Girls</a></li>
        <li><a href="searchresults.php?search=Material Walls">Material Walls</a></li>
        <li><a href="searchresults.php?search=Models">Models</a></li>
        <li><a href="searchresults.php?search=Fashions">Fashion</a></li>
      </ul>
      <ul id='dropdown2' class='dropdown-content grey accent-3' style="width: 600px;overflow: hidden;">
        <li><a href="searchresults.php?search=Animals" class="white-text">Animals</a></li>
        <li><a href="searchresults.php?search=Abstract" class="white-text">Abstract</a></li>
        <li><a href="searchresults.php?search=Architectures" class="white-text">Architectures</a></li>
        <li><a href="searchresults.php?search=Peoples" class="white-text">Peoples</a></li>
        <li><a href="searchresults.php?search=Girls" class="white-text">Girls</a></li>
        <li><a href="searchresults.php?search=Material Walls" class="white-text">Material Walls</a></li>
        <li><a href="searchresults.php?search=Models" class="white-text">Models</a></li>
        <li><a href="searchresults.php?search=Fashions" class="white-text">Fashion</a></li>
      </ul>
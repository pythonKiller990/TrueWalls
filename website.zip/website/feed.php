

<!DOCTYPE html>
<html>
<head>
	<title>Stuffy-Home</title>
	<link rel="shortcut icon" type="image/png" href="img/playstore-icon.png">
	<!-- Compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">

            
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
      <!-- Main -->



<!-- custom scrollbar stylesheet -->
  <link rel="stylesheet" href="css/jquery.mCustomScrollbar.css">

 





      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>

    </head>

<style type="text/css">
body
{
	margin: 0;
	padding: 0;
  cursor: url('cursor2.png'), auto; 

}
a
{
  cursor: url('cursor2.png'), auto; 
}

/* Let's get this party started */
::-webkit-scrollbar {
    width: 20px;
    height: 10px;
}
 
/* Track */
::-webkit-scrollbar-track {
    -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3); 
    -webkit-border-radius: 0px;
    border-radius: 0px;
}
 
/* Handle */
::-webkit-scrollbar-thumb {
    -webkit-border-radius: 0px;
    border-radius: 0px;
    background: #ffffff; 
    -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.5); 
}
::-webkit-scrollbar-thumb:window-inactive {
  background: rgba(255,0,0,0.4); 
}

img
{
  border-radius: 10px;
  transition: all 2s ease;
  transform-style: preserve-3d;
  transform: translateZ(20px);

}
img:hover
{
   box-shadow: 0 14px 28px rgba(0,0,0,0.25), 0 10px 10px rgba(0,0,0,0.22);
   filter: grayscale(5);
}
.hero           {
  min-height: 400px;
  text-align: center;
  background-image: url('img/back.jpg');
  background-size: cover;
  background-attachment: fixed;
  
}

.hero-content   {
  color: #FFF;
  padding-top: 130px;
}
.hero-content h1   {
  font-size: 100px;
  margin: 0;
}
.hero-content p    {
  font-size: 50px;
}
.hero-content a    {
  display: inline-block;
  color: #FFF;
  border: 3px solid #FFF;
  border-radius: 3px;
  padding: 15px 30px;
  margin-right: 20px;
  text-decoration: none;
  font-size: 28px;
}



#button {
  display: inline-block;
 
  text-align: center;
  position: fixed;
  bottom: 30px;
  right: 30px;
  transition: background-color .3s, 
    opacity .5s, visibility .5s;
  opacity: 0;
  visibility: hidden;
  z-index: 1000;
}
#button::after {
  content: "\f077";
  font-family: FontAwesome;
  font-weight: normal;
  font-style: normal;
  font-size: 2em;
  line-height: 50px;
  color: #fff;
}
#button:hover {
  cursor: pointer;
  background-color: #333;
}
#button:active {
  background-color: #555;
}
#button.show {
  opacity: 1;
  visibility: visible;
}
	
	
</style>
</head>
<body>
	



<div>
    <div class="navbar-fixed">
        <nav class="indigo accent-3" id="nav">
            <div class="nav-wrapper container">
                <a href="#!" class="brand-logo">TrueWalls</a>
                <a href="#" data-target="mobile-demo" class="sidenav-trigger"><i class="material-icons">menu</i></a>
                <ul class="right hide-on-med-and-down">
                    <li><a href="#"><i class="material-icons">home</i></a></li>
                    <li><a href="#"><i class="material-icons">info</i></a></li>
                    <li><a href="#"><i class="material-icons">email</i></a></li>
                </ul>
               
            </div>
        </nav>
    </div>
</div>


  <ul class="sidenav" id="mobile-demo">
    <li><a href="#">Home</a></li>
        <li><a href="#">About</a></li>
        <li><a href="#">Contact</a></li>
  </ul>
<a class="btn btn-floating grey" id="button"><i class="material-icons">arrow_upward</i></a>

  <!--main content-->
 <div class="hero">
            <!-- content for the hero -->
            <div class="hero-content">

              <div class="row">
                <div class="col s12 l6 xl5 m6">

                  <img src="img/back.jpg" class="responsive-img" style="border-radius: 50%;" width="100" height="100">
                  
                </div>
              </div>
                
                
            </div>
        </div>


        







 


 <footer class="page-footer grey accent-3">
          <div class="container">
            <div class="row">
              <div class="col l6 s12">
                <h5 class="white-text">Stuffy</h5>
                <p class="grey-text text-lighten-4">Free Wallpapers & Ringtones Library.</p>
              </div>
              <div class="col l4 offset-l2 s12">
                <h5 class="white-text">Social Links</h5>
                <ul>
          <li><a class="btn btn-large indigo waves-effect waves-light btn-floating" href="home.php" data-tilt><i class="fa fa-facebook"></i></a></li>
                  <li><a class="btn btn-large red waves-effect waves-light btn-floating" href="home.php"><i class="fa fa-instagram"></i></a></li>
                  <li><a class="btn btn-large blue waves-effect waves-light btn-floating" href="home.php"><i class="fa fa-twitter"></i></a></li>
                  
                </ul>
              </div>
            </div>
          </div>
          <div class="footer-copyright">
            <div class="container">
            © 2019 Stuffy
            
            </div>
          </div>
        </footer>
            




    <!-- Compiled and minified JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>

    <script type="text/javascript" src="js/tilt.jquery.js"></script>

    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/granim/2.0.0/granim.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>





	<script type="text/javascript">
		$(document).ready(function(){
    $('.sidenav').sidenav();
    $('.modal').modal();
    $('.fixed-action-btn').floatingActionButton({
    toolbarEnabled: true
  });
    $('.gallery').tilt({
      opacity:.5,
    
    glare: true,
    maxGlare: .5
})

    var btn = $('#button');

  $(window).scroll(function() {
    if ($(window).scrollTop() > 300) {
      btn.addClass('show');
    } else {
      btn.removeClass('show');
    }
  });

  btn.on('click', function(e) {
    e.preventDefault();
    $('html, body').animate({scrollTop:0}, '300');
  });


  });
	</script>

  <script src="js/jquery.overlayScrollbars.js"></script>


  <script type="text/javascript">

$(document).ready(function(){
 
  $(window).scroll(function(){

    

    var scroll = $(window).scrollTop();
    if (scroll > 20) {
      $(".hero").css("background-image" , "url('img/back4.png')");
      $(".hero").css("transition","2s all");
      $("body").css("background-color","grey");
      $("nav").removeClass("indigo accent-3");
      $("#button").add("grey accent-3");
      $("nav").addClass("grey accent-3");
       
    }

    else{
      $(".hero").css("background-image" , "url('img/back3.png')"); 
       $(".hero").css("transition-duration","2s");
       $("body").css("background-color","#ffffff");
       $("nav").removeClass("grey accent-3");
      $("nav").addClass("indigo accent-3");
        
      
    }
  })
})
  </script>


  <script type="text/javascript">
    function upload()
    {
      swal("Good job!", "You clicked the button!", "success");
    }
  </script>

<!-- custom scrollbar plugin -->
  <script src="js/jquery.mCustomScrollbar.js"></script>
  
  <script>
    (function($){
      $(window).on("load",function(){
        
        $("#content-1").mCustomScrollbar({
          autoHideScrollbar:true,
          theme:"rounded"
        });
        
      });
    })(jQuery);
  </script>


</body>
</html>
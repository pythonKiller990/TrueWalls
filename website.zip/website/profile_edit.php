<?php session_start(); ?>
  <?php 

  include_once 'includes/dbh.php';

  $fullname = "";
  $img = "";

  $user = "";

  
  if (isset($_SESSION['username'])) {
    $user = $_SESSION['username'];
  }
  else
  {
    $user = "Admin";
  }

  $sql = "SELECT * FROM users WHERE userid = ?";

  $stmt = mysqli_stmt_init($conn);

  if (!mysqli_stmt_prepare($stmt,$sql)) {
    echo "Statement Error!";
  }
  else
  {
    mysqli_stmt_bind_param($stmt,"s",$user);
    mysqli_stmt_execute($stmt);

    $result = mysqli_stmt_get_result($stmt);

    if ($row = mysqli_fetch_assoc($result)) {

      $userId = $row['userid'];

      $img = $row['avatar'];
      $fname = $row['fname'];

      $email = $row['email'];
      $id = $row['id'];
      $theme = $row['theme'];


      
    }
  }

  function Id()
  {
    $Id = $GLOBALS['id'];
    return $Id;
  }

  function email()
  {
    $Email = $GLOBALS['email'];
    return $Email;
  }



  function userImage()
  {
    

    $image = $GLOBALS['img'];

    
    return $image;
    
  }

  function userName()
  {
    $name = $GLOBALS['userId'];
    return $name;
  }
  function fullname()
  {
    $Fullname = $GLOBALS['fname'];
    return $Fullname;
  }



  

  ?>
<!DOCTYPE html>
<html>
  <head>
    <title>Edit Profile</title>
    <link rel="shortcut icon" type="image/png" href="img/playstore-icon.png">
    <!-- Compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    
    <!--Import Google Icon Font-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <!-- Main -->
    <!-- custom scrollbar stylesheet -->
    <link rel="stylesheet" href="css/jquery.mCustomScrollbar.css">
    
    <!--Let browser know website is optimized for mobile-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  </head>
  <style type="text/css">
  body
  {
    margin: 0;
    padding: 0;
  cursor: url('cursor2.png'), auto;
  }
  a
  {
  cursor: url('cursor2.png'), auto;
  }
  /* Let's get this party started */
  ::-webkit-scrollbar {
  width: 10px;
  height: 10px;
  }
  
  /* Track */
  ::-webkit-scrollbar-track {
  -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
  -webkit-border-radius: 10px;
  border-radius: 10px;
  }
  
  /* Handle */
  ::-webkit-scrollbar-thumb {
  -webkit-border-radius: 10px;
  border-radius: 10px;
  background: #ffffff;
  -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.5);
  }
  ::-webkit-scrollbar-thumb:window-inactive {
  background: rgba(255,0,0,0.4);
  }
  img
  {
  border-radius: 10px;
  transform-style: preserve-3d;
  transform: translateZ(20px);
  }
  #button {
  display: inline-block;
  
  text-align: center;
  position: fixed;
  bottom: 30px;
  right: 30px;
  transition: background-color .3s,
  opacity .5s, visibility .5s;
  opacity: 0;
  visibility: hidden;
  z-index: 1000;
  }
  #button::after {
  content: "\f077";
  font-family: FontAwesome;
  font-weight: normal;
  font-style: normal;
  font-size: 2em;
  line-height: 50px;
  color: #fff;
  }
  #button:hover {
  cursor: pointer;
  background-color: #333;
  }
  #button:active {
  background-color: #555;
  }
  #button.show {s
  opacity: 1;
  visibility: visible;
  }
  .btn1 {
  border: 2px solid gray;
  color: gray;
  background-color: white;
  padding: 8px 20px;
  border-radius: 8px;
  font-size: 20px;
  font-weight: bold;
  }
  .upload input[type=file] {
  font-size: 100px;
  position: absolute;
  left: 0;
  top: 0;
  opacity: 0;
  }
  .upload {
  position: relative;
  overflow: hidden;
  display: inline-block;
  }
    
    
  </style>
</head>
<?php if ($theme=='checked') {
  echo '<body style="background-color:#262626;">';
}
else{
  echo '<body style="background-color:#ffffff;">';
} ?>
  
  <div>
    <div class="navbar-fixed">
      <nav class="white" id="nav">
        <div class="nav-wrapper container">
          <a href="#!" class="brand-logo" style="color: #000;"></a>
          <a href="#" data-target="mobile-demo" class="sidenav-trigger" style="color: #000;"><i class="material-icons">menu</i></a>
          <ul class="left hide-on-med-and-down">
            <li><a href="userupload.php" class="tooltipped" data-position="center" data-tooltip="cancel" style="color: #000000"><i class="material-icons">arrow_back</i></a></li>
          </ul>
          
        </div>
      </nav>
    </div>
  </div>
  <ul class="sidenav" id="mobile-demo">
    
    <li><a href="userupload.php" class="tooltipped" data-position="center" data-tooltip="cancel" style="color: #000000"><i class="material-icons">close</i></a></li>
  </ul>
  <a class="btn btn-floating grey" id="button"><i class="material-icons">arrow_upward</i></a>
  <!--about dev ends here-->
  <!--main content-->
  
  <br><br><br><br>
  <div class="container">
    <br><br><br>
    <div class="row">
    <div class="col s12 l12 center xl12 m12">
      <center><img src="includes/avatar/<?php echo userImage(); ?>" alt="Contact Person" class="responsive-img" width="150" height="150" style="border-radius: 50%;"><br>
        <br>
        </center>
    </div>
  </div>
  <div class="row">
    <center><form class="col s12" action="includes/update.php" method="POST">
      <div class="row">
        <div class="input-field col s12">
          <input id="last_name" type="text" class="validate" value="<?php echo fullname(); ?>" name="Fname">
          <input type="hidden" name="id" value="<?php echo Id(); ?>">
          <label for="last_name">Full Name</label>
        </div>
      </div>
      <div class="row">
        <div class="input-field col s12">
          <input  id="email" type="text" class="validate" value="<?php echo email(); ?>" name="Email">
          <label for="email">Email</label>
        </div>
      </div>
      <div class="row">
        <div class="input-field col s12">
          <label>Choose a Theme:</label>
          <p>
      <label>
        <?php if ($theme=='checked') {
          echo '<input type="radio" name="theme"  value="unchecked" />';
        } 
        else
        {
          echo '<input type="radio" checked name="theme"  value="unchecked" />';
        }

        ?>
        
        <span>Light</span>
      </label>
    </p>
    <p>
      <label>
        <?php if ($theme=='checked') {
          echo '<input type="radio" checked name="theme"  value="checked" />';
        } 
        else
        {
          echo '<input type="radio" name="theme"  value="checked" />';
        }

        ?>
        <span>Dark</span>
      </label>
    </p>
        </div>
      </div>
      <div class="row">
        <div class="input-field col s12">

           <?php if ($theme=='checked') {
          echo '<input type="submit" name="update" value="Update Profile" style="color: #ffffff;border-radius: 46px;" class="btn btn-large grey accent-2">';
        } 
        else
        {
          echo '<input type="submit" name="update" value="Update Profile" style="color: #ffffff;border-radius: 46px;" class="btn btn-large teal accent-2">';
        }

        ?>
          
        </div>
      </div>

      
      
      
      
    </form></center>
  </div>
        
  </div>
  
  
  <!-- Compiled and minified JavaScript -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
  <script type="text/javascript" src="js/tilt.jquery.js"></script>
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
  <script type="text/javascript">
    $(document).ready(function(){
  $('.sidenav').sidenav();
  
  
  });
  </script>
 
 
</body>
</html>
<?php
include ('includes/dbh.php');
 
if (isset($_POST['del'])) {
	$id = $_POST['uid'];
	$sql = "DELETE  FROM galleryExamp WHERE idGallery = '$id';";

	mysqli_query($conn,$sql);
	header('location:userupload.php');
}
else
{
	echo "Failed";
}

?>
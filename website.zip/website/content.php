<div class="container">
  <center><h1 style="color: #999;" id="heading">All Walls</h1></center>
  <br><br>
  <div class="row" id="gallery">
    <?php
    include_once 'includes/dbh.php';
    $sql = "SELECT * FROM galleryExamp ORDER BY Category ASC";
    $stmt = mysqli_stmt_init($conn);
    if (!mysqli_stmt_prepare($stmt,$sql)) {
    echo "Statement Error!1";
    }
    else
    {
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    while($row = mysqli_fetch_assoc($result))
    {
    echo '
    <div class="col s12 l4 m6">
      
      <a href="#modal'.$row['orderGallery'].'" class="modal-trigger">
      <img data-progressive="includes/walls/'. $row['imgFullName'].'" class="responsive-img gallery ui-widget-content draggable progressive__img progressive--not-loaded" data-tilt  id="draggable" src="img/lq.png"></a>
      
      
    </div>
    
    ';
    }
    }
    
    ?>
  </div>
  <?php
  include_once 'includes/dbh.php';
  $sql = "SELECT * FROM galleryExamp ORDER BY orderGallery ASC";
  $stmt = mysqli_stmt_init($conn);
  if (!mysqli_stmt_prepare($stmt,$sql)) {
  echo "Statement Error!";
  }
  else
  {
  mysqli_stmt_execute($stmt);
  $result = mysqli_stmt_get_result($stmt);
  while($row = mysqli_fetch_assoc($result))
  {
  echo '
  <div id="modal'.$row['orderGallery'].'" class="modal white mymodal">
    <div class="modal-content">
      <div class="row">
        <div class="col s12 l6 m6 xl6">
          <img src="includes/walls/'.$row['imgFullName'].'" class="responsive-img materialboxed">
          
        </div>
        <div class="col s12 l6 xl6 m6">
          
          <br><br><br><br><div class="a2a_kit a2a_kit_size_32 a2a_default_style">
            <a class="a2a_button_twitter"></a>
            <a class="a2a_button_email"></a>
            <a class="a2a_button_whatsapp"></a>
          </div><br>
          
          <a href="includes/walls/'.$row['imgFullName'].'" class="btn btn-large  red" download style="border-radius:50px;">Download</a><p>Resolution: ';
          echo $row['Res'];
        echo '</p><p>Size : ';
        echo $row['size'].'MB';
      echo '</p><p>Category: ';
      echo $row['Category'];
    echo '</p><p>Upload By: ';
   echo $row['personGallery'];
    echo '</p></div>
  </div>
</div>

</div>';
}
}
?>




</div>
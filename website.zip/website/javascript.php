<script type="text/javascript">
      $(document).ready(function()
      {

            var a =$('#theme').val();
            if (a == 'checked') 
            {
                  $('#heading').css('color','#ffffff');
                  $('nav').removeClass('black accent-3');
                  $('nav').addClass('white accent-3');
                  $('#brand').removeClass('brand-logo white-text');
                  $('#brand').addClass('brand-logo black-text');
                  $('#button').removeClass('btn btn-floating teal accent-3');
                  $('#button').addClass('btn btn-floating black accent-3');
                  $('#hamburger').removeClass('material-icons white-text');
                  $('#hamburger').addClass('material-icons black-text');
                  
                  
            }
            else
            {
                  $('#heading').css('color','#999999');
                  $('nav').removeClass('white accent-3');
                  $('nav').addClass('black accent-3');
                  $('#brand').removeClass('brand-logo black-text');
                  $('#brand').addClass('brand-logo white-text');
                  $('#button').removeClass('btn btn-floating black accent-3');
                  $('#button').addClass('btn btn-floating teal accent-3');
                  $('#hamburger').removeClass('material-icons');
                  $('#hamburger').addClass('material-icons white-text');
                  
            }

      });
</script>

<!-- AddToAny BEGIN -->
<script src="https://cdn.jsdelivr.net/npm/progressively/dist/progressively.min.js"></script>
      <script async src="https://static.addtoany.com/menu/page.js"></script>
      <script src="https://kit.fontawesome.com/f3226cd6c1.js"></script>
      <!-- AddToAny END -->
      <!-- Go to www.addthis.com/dashboard to customize your tools -->
      <script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-5d1d91fe6157283f"></script>
      <!-- Compiled and minified JavaScript -->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
      <script type="text/javascript" src="js/tilt.jquery.js"></script>


      
      <script type="text/javascript">
      $(document).ready(function(){
      $('.sidenav').sidenav();
      $('.modal').modal({
        preventScrolling:true,
        opacity:0.2
        
      });
      $('.tooltipped').tooltip();
      $( "#draggable" ).draggable();
      $('.materialboxed').materialbox();
      $('.dropdown-trigger').dropdown();
       $('.fixed-action-btn').floatingActionButton();
      $('select').formSelect();
      $('.fixed-action-btn').floatingActionButton({
      direction: 'top'
      });
      $('.gallery').tilt({
      opacity:.5,
      
      glare: true,
      maxGlare: .2,
      scale:1.2
      })
      
      });
      </script>
      <script type="text/javascript">
      $(document).ready(function(){
      
      })
      </script>
      <script>
      jQuery(document).ready(function() {
      
      var btn = $('#button');
      $(window).scroll(function() {
      if ($(window).scrollTop() > 30) {
      btn.addClass('show');
      } else {
      btn.removeClass('show');
      }
      });
      btn.on('click', function(e) {
      e.preventDefault();
      $('html, body').animate({scrollTop:0}, '300');
      });
      });
      </script>

      <script type="text/javascript">
            // Select all links with hashes
$('a[href*="#"]')
  // Remove links that don't actually link to anything
  .not('[href="#"]')
  .not('[href="#0"]')
  .click(function(event) {
    // On-page links
    if (
      location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') 
      && 
      location.hostname == this.hostname
    ) {
      // Figure out element to scroll to
      var target = $(this.hash);
      target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
      // Does a scroll target exist?
      if (target.length) {
        // Only prevent default if animation is actually gonna happen
        event.preventDefault();
        $('html, body').animate({
          scrollTop: target.offset().top
        }, 1000, function() {
          // Callback after animation
          // Must change focus!
          var $target = $(target);
          $target.focus();
          if ($target.is(":focus")) { // Checking if the target was focused
            return false;
          } else {
            $target.attr('tabindex','-1'); // Adding tabindex for elements not focusable
            $target.focus(); // Set focus again
          };
        });
      }
    }
  });
      </script>

      <script type="text/javascript">
            $(document).ready(function() {
                  progressively.init({
  delay: .5,
  throttle: 50,
  smBreakpoint: 300,
  onLoad: function(elem) {
    console.log(elem);
  },
  onLoadComplete: function() {
    console.log('All images have finished loading!');
  }
});
            })
      </script>
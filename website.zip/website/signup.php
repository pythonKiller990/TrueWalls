

<!DOCTYPE html>
<html>
<head>
	<title>Stuffy-SignUp</title>
	<link rel="shortcut icon" type="image/png" href="img/playstore-icon.png">
	<!-- Compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">

            
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>



<!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
      <!-- Main -->



<!-- custom scrollbar stylesheet -->
  <link rel="stylesheet" href="css/jquery.mCustomScrollbar.css">

 





      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>

    </head>

<style type="text/css">
body
{
	margin: 0;
	padding: 0;
  cursor: url('cursor2.png'), auto; 

}
a
{
  cursor: url('cursor2.png'), auto; 
}

/* Let's get this party started */
::-webkit-scrollbar {
    width: 10px;
    height: 10px;
}
 
/* Track */
::-webkit-scrollbar-track {
    -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3); 
    -webkit-border-radius: 10px;
    border-radius: 10px;
}
 
/* Handle */
::-webkit-scrollbar-thumb {
    -webkit-border-radius: 10px;
    border-radius: 10px;
    background: #ffffff; 
    -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.5); 
}
::-webkit-scrollbar-thumb:window-inactive {
  background: rgba(255,0,0,0.4); 
}








	

.btn1 {
  border: 2px solid gray;
  color: gray;
  background-color: white;
  padding: 8px 20px;
  border-radius: 8px;
  font-size: 20px;
  font-weight: bold;
}


.upload input[type=file] {
  font-size: 100px;
  position: absolute;
  left: 0;
  top: 0;
  opacity: 0;
}
.upload {
  position: relative;
  overflow: hidden;
  display: inline-block;
}
	
</style>
</head>
<body>
	



<div>
    <div class="navbar-fixed">
        <nav class="teal accent-3" id="nav">
            <div class="nav-wrapper container">
                
                <a href="#" data-target="mobile-demo" class="sidenav-trigger"><i class="material-icons">menu</i></a>
                <ul class="right hide-on-med-and-down">
                    <li><a href="home.php" class="tooltipped" data-position="center" data-tooltip="cancel"><i class="material-icons">close</i></a></li>
                    
                </ul>
               
            </div>
        </nav>
    </div>
</div>


  <ul class="sidenav" id="mobile-demo">
    <li><a href="home.php" class="tooltipped" data-position="center" data-tooltip="refresh"><i class="material-icons">refresh</i></a></li>
                    <li><a href="#modal" class="modal-trigger tooltipped" data-position="bottom" data-tooltip="info"><i class="material-icons">info</i></a></li>
                    <li><a href="mailto:sb78639@gmail.com" class="tooltipped" data-position="bottom" data-tooltip="sb78639@gmail.com"><i class="material-icons">email</i></a></li>
  </ul>






  <!--about dev ends here-->
  <!--main content-->
 

<br>
<div class="container">




  <div class="row center">
    <form class="col s12 l12 " action="includes/reg_inc.php" method="POST" enctype="multipart/form-data">
      <div class="row">
        <div class="col s12">
          <h3 class="center">Sign Up</h3>
        </div>
      </div>
      <div class="row">
         <div class="input-field col s6">
          <input id="fullname" type="text" class="validate" name="fullname" autocomplete="off">
          <label for="fullname">Full Name</label>
        </div>
        <div class="input-field col s6">
          <input id="uid" type="text" class="validate" name="userid" autocomplete="off">
          <label for="uid">username</label>
        </div>
      </div>
      <div class="row">
        
        <div class="input-field col s12 l6">
          <input id="email" type="email" class="validate" name="email" autocomplete="off">
          <label for="email">email</label>
        </div>
         <div class="input-field col s12 l6">
          <input id="pass1" type="password" class="validate" name="pass1" autocomplete="off">
          <label for="pass1">Create Password</label>
        </div>
      </div>
      <div class="row">
        <div class="input-field col s12 l6">
          <input id="pass2" type="password" class="validate" name="pass2" autocomplete="off">
          <label for="pass2">Confirm Password</label>
        </div>
      </div>

      <div class="row">
        <div class="input-field col s12">
          <label>Choose a Theme:</label>
          <p>
      <label>
       <input type="radio" checked name="theme"  value="unchecked" />
        
        <span>Light</span>
      </label>
    </p>
    <p>
      <label>
        <input type="radio" name="theme"  value="checked" />
        <span>Dark</span>
      </label>
    </p>
        </div>
      </div>
      
      <div class="row">
        <div class="col s12">
          <div class="input-field inline">

            <input type="submit" name="reg" class="btn btn-large teal accent-3 data-tilt" value="Signup" onclick="upload();" style="border-radius: 30px;">
          </div>
        </div>
      </div>
    </form>
  </div>


	
</div>




            




    <!-- Compiled and minified JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>

   
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>





	<script type="text/javascript">
		$(document).ready(function(){
    $('.sidenav').sidenav();
    
    $('.tooltipped').tooltip();
    
   
    

   

 


  });
	</script>

  <script src="js/jquery.overlayScrollbars.js"></script>


  <script type="text/javascript">

$(document).ready(function(){
 
  $(window).scroll(function(){

    

    var scroll = $(window).scrollTop();
    if (scroll > 20) {
      
      $("nav").removeClass("indigo accent-3");
      $("nav").removeClass("teal accent-3");
      $("nav").addClass("grey accent-3");
       
    }

    else{
      
       $("nav").removeClass("grey accent-3");
      $("nav").addClass("teal accent-3");
        
      
    }
  })
})
  </script>


  <script type="text/javascript">
    function upload()
    {
      swal("Good job!", "You clicked the button!", "success");
    }
  </script>

<!-- custom scrollbar plugin -->
  <script src="js/jquery.mCustomScrollbar.js"></script>
  
  <script>
    (function($){
      $(window).on("load",function(){
        
        $("#content-1").mCustomScrollbar({
          autoHideScrollbar:true,
          theme:"rounded"
        });
        
      });
    })(jQuery);
  </script>


</body>
</html>


<!DOCTYPE html>
<html>
<head>
	<title>Stuffy-Login</title>
	<link rel="shortcut icon" type="image/png" href="img/playstore-icon.png">
	<!-- Compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">

            
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>



<!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
      <!-- Main -->



<!-- custom scrollbar stylesheet -->
  <link rel="stylesheet" href="css/jquery.mCustomScrollbar.css">

 





      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>

    </head>

<style type="text/css">
body
{
	margin: 0;
	padding: 0;
  cursor: url('cursor2.png'), auto; 

}
a
{
  cursor: url('cursor2.png'), auto; 
}

/* Let's get this party started */
::-webkit-scrollbar {
    width: 10px;
    height: 10px;
}
 
/* Track */
::-webkit-scrollbar-track {
    -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3); 
    -webkit-border-radius: 10px;
    border-radius: 10px;
}
 
/* Handle */
::-webkit-scrollbar-thumb {
    -webkit-border-radius: 10px;
    border-radius: 10px;
    background: #ffffff; 
    -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.5); 
}
::-webkit-scrollbar-thumb:window-inactive {
  background: rgba(255,0,0,0.4); 
}

img
{
  border-radius: 10px;
  transform-style: preserve-3d;
  transform: translateZ(20px);

}
img:hover
{
   box-shadow: 0 14px 28px rgba(0,0,0,0.25), 0 10px 10px rgba(0,0,0,0.22);
   filter: grayscale(5);
}
.hero           {
  min-height: 400px;
  text-align: center;
  background-image: url('img/back3.png');
  background-size: cover;
  background-attachment: fixed;
  
}
.hero:hover
{
  filter: grayscale(3);
}
.hero-content   {
  color: #FFF;
  padding-top: 130px;
}
.hero-content h1   {
  font-size: 100px;
  margin: 0;
}
.hero-content p    {
  font-size: 50px;
}
.hero-content a    {
  display: inline-block;
  color: #FFF;
  border: 3px solid #FFF;
  border-radius: 3px;
  padding: 15px 30px;
  margin-right: 20px;
  text-decoration: none;
  font-size: 28px;
}



#button {
  display: inline-block;
 
  text-align: center;
  position: fixed;
  bottom: 30px;
  right: 30px;
  transition: background-color .3s, 
    opacity .5s, visibility .5s;
  opacity: 0;
  visibility: hidden;
  z-index: 1000;
}
#button::after {
  content: "\f077";
  font-family: FontAwesome;
  font-weight: normal;
  font-style: normal;
  font-size: 2em;
  line-height: 50px;
  color: #fff;
}
#button:hover {
  cursor: pointer;
  background-color: #333;
}
#button:active {
  background-color: #555;
}
#button.show {
  opacity: 1;
  visibility: visible;
}
	
	
</style>
</head>
<body>
	



<div>
    <div class="navbar-fixed">
        <nav class="teal accent-3" id="nav">
            <div class="nav-wrapper container">
                
                <a href="#" data-target="mobile-demo" class="sidenav-trigger"><i class="material-icons">menu</i></a>
                <ul class="right hide-on-med-and-down">
                    <li><a href="home.php" class="tooltipped" data-position="center" data-tooltip="cancel"><i class="material-icons">close</i></a></li>
                    
                </ul>
               
            </div>
        </nav>
    </div>
</div>


  <ul class="sidenav" id="mobile-demo">
    <li><a href="home.php" class="tooltipped" data-position="center" data-tooltip="refresh"><i class="material-icons">refresh</i></a></li>
                    <li><a href="#modal" class="modal-trigger tooltipped" data-position="bottom" data-tooltip="info"><i class="material-icons">info</i></a></li>
                    <li><a href="mailto:sb78639@gmail.com" class="tooltipped" data-position="bottom" data-tooltip="sb78639@gmail.com"><i class="material-icons">email</i></a></li>
  </ul>






  <!--about dev ends here-->
  <!--main content-->
 

<br>
<div class="container">




 <div class="row center">
    <form class="col s12 l12 " action="includes/gallery-upload.php" method="POST" enctype="multipart/form-data">
      <div class="row">
        <div class="col s12 l12">
          <h3>Login:</h3>
        </div>
      </div>
      <div class="row">
        <div class="input-field col s12 l6">
          <input id="uid" type="text" class="validate" name="userid">
          <label for="uid">User Id</label>
          
        </div>
        <div class="input-field col l6 s12">
          <input id="pass" type="password" class="validate" name="password">
          <label for="pass">Password</label>
        </div>
      </div>
      

      <div class="row">
        <div class="col s12">
          <div class="input-field inline">
            <input type="submit" name="login" class="btn btn-large teal accent-3 data-tilt" value="Login">
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col s12">
          <div class="input-field inline">
            <a href="signup.php" class="btn btn-large teal accent-3">SignUp</a>
          </div>
        </div>
        
      </div>
    </form>

    <form action="includes/logout.php">

      <div class="row">
        <div class="col s12 l12 inline">
          <button type="submit" name="logout">Logout</button>
        </div>
      </div>
      
    </form>
  </div>

  <p>You Logged In</p>
  <p>You Logged Out</p>


	
</div>




            




    <!-- Compiled and minified JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>

   
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>





	<script type="text/javascript">
		$(document).ready(function(){
    $('.sidenav').sidenav();
    
    $('.tooltipped').tooltip();


  });
	</script>

  <script src="js/jquery.overlayScrollbars.js"></script>


  <script type="text/javascript">

$(document).ready(function(){
 
  $(window).scroll(function(){

    

    var scroll = $(window).scrollTop();
    if (scroll > 20) {
      
      $("nav").removeClass("indigo accent-3");
      $("#button").add("grey accent-3");
      $("nav").removeClass("teal accent-3");
      $("nav").addClass("grey accent-3");
       
    }

    else{
      
       $("nav").removeClass("grey accent-3");
      $("nav").addClass("teal accent-3");
        
      
    }
  })
})
  </script>


  <script type="text/javascript">
    function upload()
    {
      swal("Good job!", "You clicked the button!", "success");
    }
  </script>

<!-- custom scrollbar plugin -->
  <script src="js/jquery.mCustomScrollbar.js"></script>
  
  <script>
    (function($){
      $(window).on("load",function(){
        
        $("#content-1").mCustomScrollbar({
          autoHideScrollbar:true,
          theme:"rounded"
        });
        
      });
    })(jQuery);
  </script>


</body>
</html>
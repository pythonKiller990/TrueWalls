<?php

if(isset($_POST['update']))
{

include ('dbh.php');

// get values form input text and number
$id=$_POST['id'];

$fname = $_POST['Fname'];
$email = $_POST['Email'];

$theme = $_POST['theme'];

// mysql query to Update data
$query = "update users set fname='$fname', email='$email', theme='$theme' where id='$id'";

$result = mysqli_query($conn, $query);

if($result)
{
header('location:../userupload.php?update=success');
}else{
echo 'Data Not Updated'. mysqli_error($conn);
}
mysqli_close($conn);
}
else
{
  echo "Failed";
}
?>
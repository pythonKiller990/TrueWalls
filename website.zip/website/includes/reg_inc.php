<?php


//first check is actually clicking signup button

if (isset($_POST['reg'])) {
	require 'dbh.php';
	

	$fullname = $_POST['fullname'];
	$email = $_POST['email'];
	$pass1 = $_POST['pass1'];
	$pass2 = $_POST['pass2'];
	$userid = $_POST['userid'];
	$theme = $_POST['theme'];

	//echo $fullname ." email : ".$email." pass1 : ".$pass1. " pass2 : ".$pass2." userid: ".$userid;

	$randNo = rand(1,4);


	
	$imageFullName = "avatar".$randNo."."."png";
	
	$hashedPass= md5($pass1);
	


	//check for empty fields 


	if (empty($fullname)  || empty($email) || empty($pass1) || empty($pass2) || empty($userid)) {
		echo 'empty fields';
		exit();
	}
	
	
	else if ($pass1 !== $pass2) {
		echo "Two Password Not Matched!";
		exit();
	}

	else
	{
		//check already registred username in database
		$sql = "SELECT userid FROM users WHERE userid=?";

		$stmt = mysqli_stmt_init($conn);

		if (!mysqli_stmt_prepare($stmt,$sql)) {
			echo "statement Error";
			exit();
		}
		else
		{
			mysqli_stmt_bind_param($stmt,"s",$userid);
			mysqli_stmt_execute($stmt);
			mysqli_stmt_store_result($stmt);
			$resultCheck = mysqli_stmt_num_rows($stmt);

			if ($resultCheck > 0) {
				echo "user already taken!";
				exit();
			}
			else
			{

				$sql = "INSERT INTO users(fname,userid,email,upass,avatar,theme)VALUES(?,?,?,?,?,?);";
				$stmt = mysqli_stmt_init($conn);
				if (!mysqli_stmt_prepare($stmt,$sql)) {
					echo 'statement error2!';
					exit();
				}
				else
				{
                      mysqli_stmt_bind_param($stmt,"ssssss",$fullname,$userid,$email,$hashedPass,$imageFullName,$theme);
                      mysqli_stmt_execute($stmt);
                      move_uploaded_file($fileTempName,$directory);
					  header("location:../home.php?upload='success'");
				}


			}
		}
	}

	

	mysqli_stmt_close($stmt);
	mysqli_close($conn);
}

else
{
	header("location:home.php");
	exit();
}
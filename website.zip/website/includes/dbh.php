<?php

$server = 'localhost';
$username = 'root';
$password = "";
$dbname = "gallery";

$conn = mysqli_connect($server,$username,$password,$dbname);

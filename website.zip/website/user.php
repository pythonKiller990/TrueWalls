<div id="modal" class="modal">
        <div class="modal-content">
          <?php if (isset($_SESSION['username'])) {
          echo '<div class="row">
            <center>
            <div class="col s12 l12 xl12 m12">
              <img src="includes/avatar/';
              echo userImage();
              echo '" class="responsive-img materialboxed" width="100" height="100" style="border-radius: 50%;" data-tilt>
            </div>
            </center>
          </div>
          <div class="row">
            <center>
            <div class="col s12 l12 xl12 m12">
              <h5>';echo userName();
              echo '</h5>
              <br>
              
              <a href="userupload.php" class="btn btn-small indigo">My Uploads</a><br><br>
              <form action="includes/logout.php" method="POST">
                <button type="submit" class="btn btn-small indigo">Logout</button>
              </form>
            </div>
            </center>
          </div>';
          }
          else
          {
          echo '<div class="container">
            <div class="row center">
              <form class="col s12 l12 " action="includes/login_inc.php" method="POST">
                <div class="row">
                  <div class="col s12 l12">
                    <h3>Login:</h3>
                  </div>
                </div>
                <div class="row">
                  <div class="input-field col s12 l6">
                    <input id="uid" type="text" class="validate" name="userid">
                    <label for="uid">User Id</label>
                    
                  </div>
                  <div class="input-field col l6 s12">
                    <input id="pass" type="password" class="validate" name="password">
                    <label for="pass">Password</label>
                  </div>
                </div>
                
                <div class="row">
                  <div class="col s12">
                    <div class="input-field inline">
                      <input type="submit" name="login" class="btn btn-large teal accent-3 data-tilt" value="Login">
                    </div>
                  </div>
                </div>
                
                <div class="row">
                  <div class="col s12">
                    <div class="input-field inline">
                      <a href="forget.php" class="">Forgot Password?</a>
                    </div>
                  </div>
                  
                </div>
                <div class="row">
                  <div class="col s12">
                    <div class="input-field inline">
                      <a href="signup.php" class="">Not have account Yet!Create Account</a>
                    </div>
                  </div>
                  
                </div>
              </form>
            </div>
            
          </div>';
          }
          ?>
          
          
        </div>
        
      </div>
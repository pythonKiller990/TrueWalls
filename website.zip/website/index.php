<!DOCTYPE html>
<html>
<head>
	<title>Stuffy</title>
	<link rel="shortcut icon" type="image/png" href="img/logo.png">
	<!-- Compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">

    <!-- Compiled and minified JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
            
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="css/main.css">
<!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

      
      

<style type="text/css">

	body
	{
		background-image: url('img/back3.png');
		background-attachment: fixed;
		background-size: cover;
		opacity: .9;
		transition: 2s all;
		background-repeat: no-repeat;
	}
	
	
</style>
</head>
<body>
	



	<section class="slewedBox">
		

		<div class="container">

			<h1>TrueWalls</h1>
			<p style="color: #fff;">A Minimal Library of Wallpapers  for Your Mobile Device.</p><br>
			<a class="btn btn-large indigo waves-effect waves-light btn-floating" href="home.php"><i class="material-icons">arrow_forward</i></a>
		</div>
	</section>

	<section class="sec2">
			<h1>Free Ringtones</h1>
			<p style="color: #fff;">Get Free Ringtones for your Mobile device.</p><br>
			<button class="btn btn-large amber waves-effect waves-light btn-floating"><i class="material-icons">arrow_back</i></button>
			
		
	</section>


	<script type="text/javascript">

$(document).ready(function(){
  $(window).scroll(function(){
  	var scroll = $(window).scrollTop();
	  if (scroll > 200) {
	    $("body").css("background-image" , "url('img/back4.png')");
	    $("body").css("transition","2s all");
	  }

	  else{
		  $("body").css("background-image" , "url('img/back3.png')"); 
		   $("body").css("transition-duration","2s");
		  
	  }
  })
})
	</script>



</body>
</html>
<?php session_start(); ?>
<?php
include_once 'includes/dbh.php';
$fullname = "";
$img = "";
$user = "";
if (isset($_SESSION['username'])) {
$user = $_SESSION['username'];
}
else
{
$user = "Admin";
$theme ='unchecked';
}
$sql = "SELECT * FROM users WHERE userid = ?";
$stmt = mysqli_stmt_init($conn);
if (!mysqli_stmt_prepare($stmt,$sql)) {
echo "Statement Error!";
}
else
{
mysqli_stmt_bind_param($stmt,"s",$user);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
if ($row = mysqli_fetch_assoc($result)) {
$fullname = $row['fname'];
$img = $row['avatar'];
$userid = $row['userid'];
$theme = $row['theme'];
}
}
function theme()
{
$userTheme = $GLOBALS['theme'];
return $userTheme;
}
function userImage()
{
$image = $GLOBALS['img'];
return $image;
}
function userName()
{
$name = $GLOBALS['fullname'];
return $name;
}
function userid()
{
$uid = $GLOBALS['userid'];
return $uid;
}
?>
<?php
function Instacount()
{
$raw = file_get_contents('https://www.instagram.com/inder_jeet786'); //replace with user
preg_match('/\"edge_followed_by\"\:\s?\{\"count\"\:\s?([0-9]+)/',$raw,$m);
$count = intval($m[1]);
return $count;
}
?>
<?php function youtube()
{
// Change channelid value to match your YouTube channel ID
$url = 'https://www.youtube.com/subscribe_embed?channelid=UCTdCbTPOkekdtoOUN_Mj-AQ';
// Fetch the Subscribe button HTML
$button_html = file_get_contents( $url );
// Extract the subscriber count
$found_subscribers = preg_match( '/="0">(\d+)</i', $button_html, $matches );
if ( $found_subscribers && isset( $matches[1] ) ) {
return intval($matches[1]);
}
}?>
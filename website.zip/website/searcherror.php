<?php session_start(); ?>

 


 

<!DOCTYPE html>
<html>
<head>
	<title>Stuffy-Home</title>
	<link rel="shortcut icon" type="image/png" href="img/playstore-icon.png">
	<!-- Compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">

            
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

<!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
      <!-- Main -->



<!-- custom scrollbar stylesheet -->
  <link rel="stylesheet" href="css/jquery.mCustomScrollbar.css">

 





      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>

    </head>

<style type="text/css">
body
{
	margin: 0;
	padding: 0;
  cursor: url('cursor2.png'), auto; 

}
a
{
  cursor: url('cursor2.png'), auto; 
}

/* Let's get this party started */
::-webkit-scrollbar {
    width: 10px;
    height: 10px;
}
 
/* Track */
::-webkit-scrollbar-track {
    -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3); 
    -webkit-border-radius: 10px;
    border-radius: 10px;
}
 
/* Handle */
::-webkit-scrollbar-thumb {
    -webkit-border-radius: 10px;
    border-radius: 10px;
    background: #ffffff; 
    -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.5); 
}
::-webkit-scrollbar-thumb:window-inactive {
  background: rgba(255,0,0,0.4); 
}






	
</style>
</head>
<body>
	



<div>
    <div class="navbar-fixed">
        <nav class="white" id="nav">
            <div class="nav-wrapper container">
                <a href="#!" class="brand-logo" style="color: #000;"></a>
                <a href="#" data-target="mobile-demo" class="sidenav-trigger" style="color: #000;"><i class="material-icons">menu</i></a>
                <ul class="left hide-on-med-and-down">
                    <li><a href="home.php" class="tooltipped" data-position="center" data-tooltip="cancel" style="color: #000000"><i class="material-icons">arrow_back</i></a></li>
                </ul>
               
            </div>
        </nav>
    </div>
</div>


  <ul class="sidenav" id="mobile-demo">
    
                    <li><a href="home.php" class="tooltipped" data-position="center" data-tooltip="cancel" style="color: #000000"><i class="material-icons">close</i></a></li>

  </ul>








  <!--about dev ends here-->
  <!--main content-->
 

<br><br><br><br>
<div class="container">
  

  <div class="row">
    <div class="col l12 s12 md12 xl12">
      <center><img src="img/emoji.png" width="120" height="120" class="responsive-img"><br><br>
        <h2>Sorry, No Result Found!</h2><br><br>
        <a href="home.php" class="btn btn-large transparent" style="border:2px solid;border-radius: 20px;color: #000;">Try Again</a></center>
    </div>
  </div>
  
  


</div>





 
            




    <!-- Compiled and minified JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>

    <script type="text/javascript" src="js/tilt.jquery.js"></script>

    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>








  




</body>
</html>
<div class="navbar-fixed">
          <nav class="black accent-3" id="nav">
            <div class="nav-wrapper container">
              <a href="#!" class="brand-logo white-text" id="brand">TrueWalls</a>
              <a href="#" data-target="mobile-demo" class="sidenav-trigger black-text"><i class="material-icons" id="hamburger">menu</i></a>
              <ul class="right hide-on-med-and-down">
                <li><a href="#modal" class="modal-trigger tooltipped btn btn-floating indigo pulse" data-position="bottom" data-tooltip="Your Account"><i class="material-icons">person</i></a></li>
                <li><a href="#modalupload" class="modal-trigger tooltipped btn btn-floating teal accent-3 pulse" data-position="bottom" data-tooltip="upload"><i class="material-icons">file_upload</i></a></li>
                <li><a href="about.php" class="tooltipped btn btn-floating teal darken-1 pulse" data-position="bottom" data-tooltip="About Dev"><i class="material-icons">info</i></a></li>
                <li><a href="#" class='dropdown-trigger btn amber darken-1 btn-floating pulse' data-target='dropdown2'><i class="material-icons">arrow_drop_down</i> </a></li>
              </ul>
              
            </div>
          </nav>
        </div>
      
<html>
<head>
<title>Page Load Time</title>
<?php
$start_time = microtime(TRUE);
?>

</head>
<body>
	
<h1>Get Page Loading Time Using PHP</h1>
    
<?php
$end_time = microtime(TRUE);
$time_taken =($end_time - $start_time)*1000;
$time_taken = round($time_taken,5);
echo '<p>Page generated in '.$time_taken.' seconds.</p>';
?>

</body>
</html>


<ul class="sidenav" id="mobile-demo">
        <li><a href="#modal" class="modal-trigger tooltipped" data-position="bottom" data-tooltip="Your Account">Your Account</a></li>
        <li><a href="mailto:sb78639@gmail.com" class="tooltipped" data-position="bottom" data-tooltip="Email">Contact Us</a></li>
        <li><a href="#modalupload" class="modal-trigger tooltipped" data-position="bottom" data-tooltip="upload">Upload</a></li>
        <li><a href="about.php" class="tooltipped" data-position="bottom" data-tooltip="About Dev">About Me</a></li>
        <li><a href="#" class='dropdown-trigger btn amber accent-3' data-target='dropdown1'>Categories</a></li>
      </ul>
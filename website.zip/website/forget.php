<!DOCTYPE html>
<html>
	<head>
		<title>Forgot-Password</title>
		<link rel="shortcut icon" type="image/png" href="img/playstore-icon.png">
		<!-- Compiled and minified CSS -->
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
		
		<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
		<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
		<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
		
		<!--Import Google Icon Font-->
		<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
		<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
		<!-- Main -->
		<!-- custom scrollbar stylesheet -->
		<link rel="stylesheet" href="css/jquery.mCustomScrollbar.css">
		
		<!--Let browser know website is optimized for mobile-->
		<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
		<style type="text/css">
			body
			{
				margin: 0;
				padding:0;
			}
			@media screen (max-width: 768px)
			{
				body
				{
					background-color:#262626;
				}
			}
		</style>
	</head>
	<body>
		<br><br><br><br><br>
		<div class="container">
			<div class="row">
				<div class="col s12 l12 xs12">
					<center><img src="img/lock.png" width="150" height="150"></center>
				</div>
				
			</div>
			<div class="row">
				<div class="col s12 l12 xs12">
					<center><span style="font-size: 25px;color: #999;">Enter Your Registred Mobile Number</span></center>
				</div>
			</div>
			
			<div class="row">
				<form class="col s12" action="" method="POST">
					<div class="row">
						<div class="input-field col s12 l12">
							<input id="phone" type="text" class="validate" name="phone">
							<label for="phone">Phone Number</label>
						</div>
						
					</div>
					<div class="row">
						<div class="input-field col s12 l12">
							<input id="btn" type="submit" value="Send OTP" class="btn purple accent-3" name="send">
							
						</div>
					</div>
				</form>
			</div>

			<!--ERROR MESSAGE ON WRONG MOBILE NUMBER-->
			

			<div class="error">
				<center><p id="error_message" class="red-text"></p></center>
			</div>
			
			
			
		</div>
		<!-- Compiled and minified JavaScript -->
		<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
		
		
	</body>
</html>
<!--logic-->
<?php
if (isset($_POST['send'])) {
	$mobno= $_POST['phone'];

	include 'includes/dbh.php';

	$randomNo = rand(0,9)*1000000;

	$sql = "SELECT * FROM users WHERE mobile='$mobno'";



	$result = mysqli_query($conn,$sql);

	if (mysqli_num_rows($result)>0) {

		$sql = "UPDATE users set otp = '$randomNo' WHERE mobile = '$mobno'";
		mysqli_query($sql,$conn);
		
	}
	else
	{
		echo '<script>document.getElementById("error_message").innerHTML="Mobile number not Exist";</script>';
	}


	function sendSms()
	{
		//post
$url="https://www.way2sms.com/api/v1/sendCampaign";
$message = urlencode("message-text");// urlencode your message
$curl = curl_init();
curl_setopt($curl, CURLOPT_POST, 1);// set post data to true
curl_setopt($curl, CURLOPT_POSTFIELDS, "apikey=[povided-api-key]&secret=[provided-secret-key]&usetype=[stage or prod]&phone=[to-mobile]&senderid=[active-sender-id]&message=[$message]");// post data
// query parameter values must be given without squarebrackets.
 // Optional Authentication:
curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
$result = curl_exec($curl);
curl_close($curl);
echo $result;
	}
	
}
?>
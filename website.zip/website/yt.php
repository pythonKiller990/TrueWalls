<?php function youtube()
{


// Change channelid value to match your YouTube channel ID
$url = 'https://www.youtube.com/subscribe_embed?channelid=UCTdCbTPOkekdtoOUN_Mj-AQ';

// Fetch the Subscribe button HTML
$button_html = file_get_contents( $url );

// Extract the subscriber count
$found_subscribers = preg_match( '/="0">(\d+)</i', $button_html, $matches );

if ( $found_subscribers && isset( $matches[1] ) ) {
    
    return intval($matches[1]);
}


}

echo youtube();
<div id="modalupload" class="modal">
    <div class="modal-content">
      <?php if (isset($_SESSION['username'])) {
      echo '<div class="row center">
        <form class="col s12 l12 " action="includes/gallery-upload.php" method="POST" enctype="multipart/form-data">
          <div class="row">
            <div class="col s12 l12">
              <h6>Upload Your Image:</h6>
            </div>
          </div>
          <div class="row">
            <div class="input-field col s12 l12">
              <input placeholder="Your Name" type="text" name="personname" id="pname" class="validate" value="';
              echo userName();
              echo '" readonly>
              
            </div>
            <div class="input-field col s12 l12">
              <input placeholder="Your userid" type="text" name="userid" id="uid" class="validate" value="';
              echo userid();
              echo '" readonly>
              
            </div>
          </div>
          <div class="row">
            
             <div class="input-field col s12">
    <select name="category">
      <option value="Miscellaneous" disabled selected>Choose a Category</option>
      <option value="Animals">Animals</option>
      <option value="Abstract">Abstract</option>
      <option value="Girls">Girls</option>
       <option value="Models">Models</option>
        <option value="Material Walls">Material Walls</option>
         <option value="Architectures">Architectures</option>
          <option value="Peoples">Peoples</option>
          <option value="Fashions">Fashions</option>
    </select>
    
  </div>
          </div>
          
          <div class="row">
            <div class="input-field col s6 upload">
              <center><button class="btn1">choose a file</button></center>
              <input id="file" type="file" name="file">
              
            </div>
          </div>
          <div class="row">
            <div class="col s12">
              <div class="input-field inline">
                
                <input type="submit" name="upload" class="btn btn-large purple data-tilt" value="upload" onclick="upload();" style="border-radius:46px;">
              </div>
            </div>
          </div>
        </form>
      </div>';
      }
      else
      {
      echo 'You Have To be Login First To Upload';
      }
      ?>
      
      
    </div>
    
  </div>